﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EBHAPI.BusinessLayer.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EBHAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private ICommonEngineService _commonEngineService;

        public CommonController(ICommonEngineService commonEngineService)
        {
            this._commonEngineService = commonEngineService;
        }
       
    }
}
