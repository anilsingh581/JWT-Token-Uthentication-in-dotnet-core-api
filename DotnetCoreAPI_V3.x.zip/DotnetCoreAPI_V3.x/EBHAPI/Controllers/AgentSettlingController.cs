﻿using System;
using System.Collections.Generic;
using EBHAPI.BusinessLayer.Interfaces;
using EBHAPI.Logger.Interface;
using EBHAPI.Logger.LogEngine;
using EBHAPI.Logger.LogEntity;
using EBHAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBHAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AgentSettlingController : ControllerBase
    {
        private IAgentSetllingEngineService _agentSettlingEngineService;
        readonly ILogger _logger = new LoggerEngine();
        private BaseDataAccess _dbContext;
        public AgentSettlingController(IAgentSetllingEngineService agentSetllingEngineService, BaseDataAccess dbContext)
        {
            this._agentSettlingEngineService = agentSetllingEngineService;
            this._dbContext = dbContext;
        }

        #region AgentSetlling

        // GET: api/AgentSettling/GetAgentSetllingSummary
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetAgentSetllingSummary(string userId)
        {
            try
            {
                //string Key = Request.Headers["Authorization"].ToString();

                var result = _agentSettlingEngineService.GetAgentSetllingSummary(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetAgentSetllingSummary", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }


        [HttpGet]
        [Route("[action]")]
        public IActionResult GetAgentSetllingGrid(string userId)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetAgentSetllingGrid(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetAgentSetllingSummary", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        // POST: api/AgentSettling/AddAgentSettling
        [HttpPost]
        [Route("[action]")]
        public IActionResult AddAgentSettling(string userId,string vendorCode,string agentCode,string AccountDate)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.AddAgentSettling(userId, vendorCode, agentCode, AccountDate);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        // POST: api/AgentSettling/usp_CheckInsertAgentYouareSettling
        [HttpGet]
        [Route("[action]")]
        public IActionResult CheckInsertAgentYouareSettling(string userId)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.CheckInsertAgentYouareSettling(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "CheckInsertAgentYouareSettling", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        [HttpGet]
        [Route("[action]")]
        public IActionResult CheckAgentStlVendorCodeForStl_AAR(string userId)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.CheckAgentStlVendorCodeForStl_AAR(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "CheckAgentStlVendorCodeForStl_AAR", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        [HttpPost]
        [Route("[action]")]
        public IActionResult DeleteSettlingAgents(string userId,string VendorCode)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.DeleteSettlingAgents(userId, VendorCode);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "DeleteSettlingAgents", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        [HttpGet]
        [Route("[action]")]
        public IActionResult GetAdjustmentGridDetails(string userId, string vendorCode)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetAdjustmentGridDetail(userId, vendorCode);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        [HttpGet]
        [Route("[action]")]
        public IActionResult GetSummaryOrderDetails(string userId, string vendorCode)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetSummaryOrderDetails(userId, vendorCode);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }


        [HttpGet]
        [Route("[action]")]
        public IActionResult GetSummaryOrdersWithFlag(string userId, string vendorCode)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetSummaryOrdersWithFlag(userId, vendorCode);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }


        [HttpGet]
        [Route("[action]")]
        public IActionResult GetSummaryOrdersNextWeek(string userId, string vendorCode,string accountingWeek)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetSummaryOrdersNextWeek(userId, vendorCode, accountingWeek);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }


        [HttpPost]
        [Route("[action]")]
        public IActionResult UpdateMoveWeek([FromBody] MoveWeekObject moveWeekObjects)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.UpdateMoveWeekData(moveWeekObjects);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "DeleteSettlingAgents", "", _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }


        // GET: api/AgentSettling/GetAgentSetllingSummary
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetAgentSetllingSummaryNegativeSettlement(string userId)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetAgentSetllingSummaryNegativeSettlement(userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetAgentSetllingSummary", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }




        #endregion

        #region SettleOrderReviewDetail

        // GET: api/AgentSettling/GetSettleOrderReviewDetails
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetSettleOrderReviewDetail(string userId, string orderId)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetSettleOrderReviewDetail(userId, orderId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSettleOrderReviewDetail", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }


        // GET: api/AgentSettling/GetOverrideSettlementOrderReview
        [HttpGet]
        [Route("[action]")]
        public IActionResult GetOverrideSettlementOrderReview(string userId, int agentTransFlagId)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.OverrideSettlementOrderReview(userId, agentTransFlagId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetOverrideSettlementOrderReview", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        #endregion

        #region  ModifyAgentAdjustments

        // GET: api/AgentSettling/GetModifyAgentAdjustmentsData
        [HttpGet]
        [Route("[action]")]
        public ActionResult GetModifyAgentAdjustmentsData(string userId, string vendorCode, int curAcctingWeek, string curAcctingDate, string agentCode)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetModifyAgentAdjustmentsData(userId, vendorCode, curAcctingWeek, curAcctingDate, agentCode);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetModifyAgentAdjustmentsData", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        // POST: api/AgentSettling/AddNewModifyAgentAdjustments
        [HttpPost]
        [Route("[action]")]
        public IActionResult AddNewModifyAgentAdjustments([FromBody] ModifyAgentAdjustment modifyAgentAdjustment)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.AddNewModifyAgentAdjustments(modifyAgentAdjustment);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", modifyAgentAdjustment.UserId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        // POST: api/AgentSettling/SaveModifyAgentAdjustments
        [HttpPost]
        [Route("[action]")]
        public IActionResult SaveModifyAgentAdjustments([FromBody] UpdateModifyAgentAdjustment updatemodifyAgentAdjustment)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.SaveModifyAgentAdjustments(updatemodifyAgentAdjustment);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", updatemodifyAgentAdjustment.UserId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        // GET: api/AgentSettling/GetPayCodeDesc
        [HttpGet]
        [Route("[action]")]
        public ActionResult GetPayCodeDesc(string userId, string payCode)
        {
            try
            {
                //TODO Logger
                var result = _agentSettlingEngineService.GetPayCodeDesc(userId, payCode);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetPayCodeDesc", userId, _dbContext.GetLoggerConnection().ConnectionString);
                Response responseModel = new Response();
                responseModel.Status = false;
                responseModel.Message = "500 Internal Server Error";
                responseModel.Data = "";
                return Ok(responseModel);
            }
        }

        #endregion

        // GET: api/AgentSettling
        [HttpGet]
        public IActionResult Get()
        {
            Response responseModel = new Response();
            responseModel.Status = true;
            responseModel.Message = "";
            responseModel.Data = new string[] { "value1", "value2" };
            return Ok(responseModel);
        }       
    }
}
