﻿using System.Collections.Generic;
using EBHAPI.BusinessLayer.EngineServices;
using EBHAPI.BusinessLayer.Interfaces;
using EBHAPI.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EBHAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private IAuthEngineService _authEngineService;

        public UsersController(IAuthEngineService authEngineService)
        {
            this._authEngineService = authEngineService;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public IActionResult Authenticate([FromBody]AuthenticateModel model)
        {
            var user = _authEngineService.Authenticate(model.Username, model.Password);

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            return Ok(user);
        }

        // GET: api/JWTUsers
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }       
    }
}
