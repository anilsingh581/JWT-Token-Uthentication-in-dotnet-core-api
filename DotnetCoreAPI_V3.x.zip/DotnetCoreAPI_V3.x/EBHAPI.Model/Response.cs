﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Model
{
    public class Response
    {
        public bool Status { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }
        //public object CustomModel { get; set; }
    }
}
