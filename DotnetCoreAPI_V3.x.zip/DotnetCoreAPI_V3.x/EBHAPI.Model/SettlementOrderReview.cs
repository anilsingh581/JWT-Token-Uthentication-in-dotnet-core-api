﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Model
{
    public class SettlementOrderReview
    {
        public string SettlePronum { get; set; }
        public int SettleBrk { get; set; }
        public string SettlePayType { get; set; }
        public string SettleRevenue { get; set; }
        public string SettlePay { get; set; }
        public string SettleCommission { get; set; }
        public string SettleBillingDate { get; set; }
        public string SettleAcctingDate { get; set; }
        public int SettleAcctingWeek { get; set; }
        public string SettlereviewFlagConMet { get; set; }
    }
}
