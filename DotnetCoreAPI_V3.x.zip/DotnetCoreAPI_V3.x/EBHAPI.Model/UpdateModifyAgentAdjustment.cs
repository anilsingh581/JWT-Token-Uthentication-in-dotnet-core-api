﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Model
{
    public class UpdateModifyAgentAdjustment
    {
        public string UserId { get; set; }
        public List<AgentAdjustmentObj> AmountObj { get; set; }
    }
    public class AgentAdjustmentObj
    {
        public int adjustmentId { get; set; }
        public decimal adjustmentAmount { get; set; }
        public string adjustmentVendorCode { get; set; }
        public string actionType { get; set; }
    }
}
