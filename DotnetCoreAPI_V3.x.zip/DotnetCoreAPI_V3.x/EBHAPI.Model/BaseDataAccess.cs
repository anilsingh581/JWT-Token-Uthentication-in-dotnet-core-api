﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace EBHAPI.Model
{
    public class BaseDataAccess
    {
        public string ConnectionString { get; set; }
        public string LoggerConnectionString { get; set; }

        public BaseDataAccess(string connectionString, string loggerConnectionString)
        {
            this.ConnectionString = connectionString;
            this.LoggerConnectionString = loggerConnectionString;
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        public SqlConnection GetLoggerConnection()
        {
            return new SqlConnection(LoggerConnectionString);
        }
    }
}
