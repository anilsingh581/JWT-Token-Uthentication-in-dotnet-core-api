﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Model
{
    public class ModifyAgentAdjustment
    {
        public string UserId { get; set; }
        public int AGENT_ADJUST_ID { get; set; }        
        public int AGENT_ADJUST_MAX_TRANS { get; set; }
        public string AGENT_ADJUST_FREQ { get; set; }
        public string AGENT_ADJUST_AMOUNT_TYPE { get; set; }
        public string AGENT_ADJUST_STATUS { get; set; }
        public float AGENT_ADJUST_AMOUNT { get; set; }
        public string AGENT_ADJUST_NOTE { get; set; }
        public int AGENT_TRANS_ID { get; set; }
        public string AGENT_TRANS_TYPE { get; set; }
        public string AGENT_TRANS_ACCTING_DATE { get; set; }
        public int AGENT_TRANS_ACCTING_WK { get; set; }
        public string AGENT_TRANS_LOC_OR_TRAC { get; set; }
        public string AGENT_TRANS_VENDOR_CODE { get; set; }
        public string AGENT_TRANS_PAY_TYPE { get; set; }
    }
}
