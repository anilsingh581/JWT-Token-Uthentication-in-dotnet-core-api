﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Model
{
    public class MoveWeekObject
    {
        public string userId { get; set; }
        public List<MoveWeekObj> moveWeekObjs { get; set; }
    }
    public class MoveWeekObj
    {       
        public string ProNumber { get; set; }      
        public int accountWeek { get; set; }
    }



}
