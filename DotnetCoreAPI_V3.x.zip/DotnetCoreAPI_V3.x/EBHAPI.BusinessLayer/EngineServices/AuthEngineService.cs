﻿using EBHAPI.BusinessLayer.Interfaces;
using EBHAPI.Common;
using EBHAPI.Logger.Interface;
using EBHAPI.Logger.LogEngine;
using EBHAPI.Logger.LogEntity;
using EBHAPI.Model;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace EBHAPI.BusinessLayer.EngineServices
{
    public class AuthEngineService : IAuthEngineService
    {
        private BaseDataAccess _dbContext;
        private readonly AppSettings _appSettings;
        readonly ILogger _logger = new LoggerEngine();

        public AuthEngineService(BaseDataAccess dbContext, IOptions<AppSettings> appSettings)
        {
            this._dbContext = dbContext;
            this._appSettings = appSettings.Value;
        }

        /// <summary>
        /// AUTHENTICATE AND GENERATE TOKEN TO VALIDATE API REQUIST
        /// </summary>
        public User Authenticate(string username, string password)
        {
            User user = null;
            try
            {
                //DECRYPT TO ENCRYPTED DATA.
                if(!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
                {
                    username = EncryptionHelper.Decrypt(username);
                    password = EncryptionHelper.Decrypt(password);
                }
                else
                {
                    return null;
                }
                

                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "dbo.usp_GetAuthenticateAsyncDetails",
                           new SqlParameter("@UserName", username),
                           new SqlParameter("@Password", password));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        DataTable dt = ds.Tables[0];
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            DataRow row = dt.Rows[0];

                            user = new User
                            {
                                Id = Convert.IsDBNull(row["User_Id"]) ? 0 : Convert.ToInt32(row["User_Id"]),
                                FirstName = Convert.IsDBNull(row["User_fname"]) ? null : Convert.ToString(row["User_fname"]),
                                LastName = Convert.IsDBNull(row["User_lname"]) ? null : Convert.ToString(row["User_lname"]),
                                Username = null,// Convert.IsDBNull(row["User_Login"]) ? null : Convert.ToString(row["User_Login"]),
                                Password = null
                            };
                        }
                    }
                }

                // return null if user not found
                if (user == null)
                    return null;

                // authentication successful so generate jwt token
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                    new Claim(ClaimTypes.Name, user.Id.ToString())
                    }),
                    Expires = DateTime.UtcNow.AddHours(8),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                user.Token = tokenHandler.WriteToken(token);
                user.Id = 0;//Reset Ids
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "Authenticate API with Bearer Token", username, _dbContext.GetLoggerConnection().ConnectionString);

            }
            
            return user;
        }
    }
}
