﻿using EBHAPI.BusinessLayer.Interfaces;
using EBHAPI.Common;
using EBHAPI.Logger.Interface;
using EBHAPI.Logger.LogEngine;
using EBHAPI.Logger.LogEntity;
using EBHAPI.Model;
using System;
using System.Data;
using System.Data.SqlClient;

namespace EBHAPI.BusinessLayer.EngineService
{
    public class AgentSetllingEngineService : IAgentSetllingEngineService
    {
        private BaseDataAccess _dbContext;
        readonly ILogger _logger = new LoggerEngine();

        public AgentSetllingEngineService(BaseDataAccess dbContext)
        {
            this._dbContext = dbContext;
        }

        #region AgentSetlling

        /// <summary>
        /// THIS METHOD IS USED FOR GET AGENT SETLLING SUMMARY DETAILS
        /// </summary>
        public Response GetAgentSetllingSummary(string userId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetSettlementSummaryDetail",
                                    new SqlParameter("@userId", userId));
                    if (ds.Tables != null)
                    {
                        if(ds.Tables[0].Rows.Count > 0)
                        {
                            responseModel.Status = true;
                            responseModel.Message = "Data get successfully.";
                            responseModel.Data = ds;
                            return responseModel;
                        }
                        else if (ds.Tables[1].Rows.Count > 0)
                        {
                            responseModel.Status = true;
                            responseModel.Message = "Data get successfully.";
                            responseModel.Data = ds;
                            return responseModel;
                        }
                        else if (ds.Tables[2].Rows.Count > 0)
                        {
                            responseModel.Status = true;
                            responseModel.Message = "Data get successfully.";
                            responseModel.Data = ds;
                            return responseModel;
                        }
                        else
                        {
                            responseModel.Status = false;
                            responseModel.Message = "No record found";
                            responseModel.Data = "";
                        }
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetAgentSetllingSummary", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED FOR GET AGENT SETLLING SUMMARY DETAILS
        /// </summary>
        public Response GetAgentSetllingGrid(string userId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetAgentSettlingGrid",
                                    new SqlParameter("@currentLoginId", userId));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = ds;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetAgentSetllingSummary", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED FOR INSERT AGENT SETLLING GRID
        /// </summary>
        public Response AddAgentSettling(string userId, string vendorCode, string agentCode, string AccountDate)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    int result = SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_InsertAgentsSettling",
                                    new SqlParameter("@currentLogin", userId),
                                    new SqlParameter("@vendorCode", vendorCode),
                                    new SqlParameter("@agentCode", agentCode),
                                    new SqlParameter("@currentAccountingDate", AccountDate));
                    if (result != 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data insert successfully.";
                        responseModel.Data = true;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record insert";
                        responseModel.Data = false;                        
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED TO CHECK INSERTAGENTYOUARESETTLING FOR INSERT AGENT SETLLING GRID
        /// </summary>
        public Response CheckInsertAgentYouareSettling(string userId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_CheckAgentStlVendorCode",
                                    new SqlParameter("@userId", userId));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data Get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "CheckInsertAgentYouareSettling", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED TO CHECK INSERT AAR_AGENTYOUARESETTLING  FOR INSERT AGENT SETLLING GRID
        /// </summary>
        public Response CheckAgentStlVendorCodeForStl_AAR(string userId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_CheckAgentStlVendorCodeForStl_AAR",
                                    new SqlParameter("@userId", userId));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data Get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "CheckAgentStlVendorCodeForStl_AAR", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED TO DELETE Agent SETLLING 
        /// </summary>
        /// 
        public Response DeleteSettlingAgents(string userId, string vendorCode)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    int result = SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_DeleteSettlingAgentsGrid",
                                    new SqlParameter("@userId", userId),
                                    new SqlParameter("@vendorCode", vendorCode));
                    if (result != 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data Delete successfully.";
                        responseModel.Data = true;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record Delete";
                        responseModel.Data = false;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "DeleteSettlingAgents", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED TO Get Summary ORDERDETAILS SETLLING GRID
        /// </summary>
        /// 
        public Response GetSummaryOrderDetails(string userId, string vendorCode)
        { 
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetSummaryOrderDetails",
                                    new SqlParameter("@userId", userId),
                                    new SqlParameter("@vendorCode", vendorCode));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USED TO Get Adjustment Grid Detail
        /// </summary>
        /// 
        public Response GetAdjustmentGridDetail(string userId, string vendorCode)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetAdjustmentDetail",
                                   // new SqlParameter("@userId", userId),
                                    new SqlParameter("@vendorCode", vendorCode));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// THIS METHOD IS USED TO Get Summary ORDERDETAILS SETLLING Show Only Orders with Flags
        /// </summary>

        public Response GetSummaryOrdersWithFlag(string userId, string vendorCode)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetSummaryOrderWithFlag",
                                    new SqlParameter("@userId", userId),
                                    new SqlParameter("@vendorCode", vendorCode));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USED TO Get Summary ORDERDETAILS SETLLING Show Only Orders Next Week
        /// </summary>

        public Response GetSummaryOrdersNextWeek(string userId, string vendorCode,string accountingWeek)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetSummaryOrderNextWeek",
                                    new SqlParameter("@userId", userId),
                                    new SqlParameter("@vendorCode", vendorCode),
                                    new SqlParameter("@accountingWeek", accountingWeek));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSummaryOrderDetails", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USED TO UPDATE Orders  SUMMARY DETAILS ACCOUNTING  Week
        /// </summary>
        public Response UpdateMoveWeekData(MoveWeekObject moveWeekObjects)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    for (int i = 0; moveWeekObjects.moveWeekObjs.Count > i; i++)
                    {
                        int result = SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_UpdateMoveWeeks",
                                     new SqlParameter("@proNumber", moveWeekObjects.moveWeekObjs[i].ProNumber),
                                     new SqlParameter("@accountWeek", moveWeekObjects.moveWeekObjs[i].accountWeek),
                                     new SqlParameter("@agentTransNumber", ""),
                                     new SqlParameter("@userId", moveWeekObjects.userId)
                                     );
                        if (result != 0)
                        {
                            responseModel.Status = true;
                            responseModel.Message = "Data insert successfully.";
                            responseModel.Data = true;
                            return responseModel;
                        }
                        else
                        {
                            responseModel.Status = false;
                            responseModel.Message = "No record insert";
                            responseModel.Data = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", "", _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }


        /// <summary>
        /// THIS METHOD IS USED FOR GET AGENT SETLLING SUMMARY DETAILS THOSE DATA HAVE NEGATIVE SETTLEMENT
        /// </summary>
        public Response GetAgentSetllingSummaryNegativeSettlement(string userId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetSettlementSummaryDetailNegativeSettlement",
                                    new SqlParameter("@userId", userId));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = ds;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetAgentSetllingSummary", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        #endregion

        #region SettleOrderReviewDetail
        /// <summary>
        /// THIS METHOD IS USED FOR GET LIST OF SETTLE ORDER REVIEW DETAILS
        /// </summary>
        public Response GetSettleOrderReviewDetail(string userId, string orderId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetSettleOrderReviewDetails",
                                    new SqlParameter("@userId", userId), new SqlParameter("@orderId", orderId));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = ds;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSettleOrderReviewDetail", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }


        public Response OverrideSettlementOrderReview(string userId, int agentTransFlagId)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_OverrideSettlementOrderReview",
                                    new SqlParameter("@UserId", userId),
                                    new SqlParameter("@AgentTransFlagId", agentTransFlagId));
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data Override successfully.";
                        responseModel.Data = ds;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetSettleOrderReviewDetail", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }
        #endregion

        #region ModifyAgentAdjustments
        /// <summary>
        /// THIS METHOD IS USED FOR GET MODIFY AGENT ADJUSTMENTS DATA
        /// </summary>
        public Response GetModifyAgentAdjustmentsData(string userId, string vendorCode, int curAcctingWeek, string curAcctingDate, string agentCode)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetModifyAgentAdjustmentsData",
                                    new SqlParameter("@userId", userId),
                                    new SqlParameter("@Vendor_code", vendorCode),
                                    new SqlParameter("@Cur_accting_wk", curAcctingWeek),
                                    new SqlParameter("@Cur_accting_dt", curAcctingDate),
                                    new SqlParameter("@Agent_code", agentCode)
                                   );
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetModifyAgentAdjustmentsData", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// USed to Save Modify Agent Adjustments 
        /// </summary>
        /// <returns></returns>
        public Response AddNewModifyAgentAdjustments(ModifyAgentAdjustment modifyAgentAdjustment)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    int result = SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_AddNewModifyAgentAdjustments",
                                    new SqlParameter("@userId", modifyAgentAdjustment.UserId),
                                    new SqlParameter("@AGENT_ADJUST_MAX_TRANS", modifyAgentAdjustment.AGENT_ADJUST_MAX_TRANS),
                                    new SqlParameter("@AGENT_ADJUST_FREQ", modifyAgentAdjustment.AGENT_ADJUST_FREQ),
                                    new SqlParameter("@AGENT_ADJUST_AMOUNT_TYPE", modifyAgentAdjustment.AGENT_ADJUST_AMOUNT_TYPE),
                                    new SqlParameter("@AGENT_ADJUST_STATUS", modifyAgentAdjustment.AGENT_ADJUST_STATUS),
                                    new SqlParameter("@AGENT_ADJUST_AMOUNT", modifyAgentAdjustment.AGENT_ADJUST_AMOUNT),
                                    new SqlParameter("@AGENT_ADJUST_NOTE", modifyAgentAdjustment.AGENT_ADJUST_NOTE),
                                    new SqlParameter("@AGENT_TRANS_TYPE", modifyAgentAdjustment.AGENT_TRANS_TYPE),
                                    new SqlParameter("@AGENT_TRANS_ACCTING_DATE", modifyAgentAdjustment.AGENT_TRANS_ACCTING_DATE),
                                    new SqlParameter("@AGENT_TRANS_ACCTING_WK", modifyAgentAdjustment.AGENT_TRANS_ACCTING_WK),
                                    new SqlParameter("@AGENT_TRANS_LOC_OR_TRAC", modifyAgentAdjustment.AGENT_TRANS_LOC_OR_TRAC),
                                    new SqlParameter("@AGENT_TRANS_VENDOR_CODE", modifyAgentAdjustment.AGENT_TRANS_VENDOR_CODE),
                                    new SqlParameter("@AGENT_TRANS_PAY_TYPE", modifyAgentAdjustment.AGENT_TRANS_PAY_TYPE));
                    if (result != 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data insert successfully.";
                        responseModel.Data = true;
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record insert";
                        responseModel.Data = false;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", modifyAgentAdjustment.UserId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        public Response SaveModifyAgentAdjustments(UpdateModifyAgentAdjustment updatemodifyAgentAdjustment)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    for (int i = 0; updatemodifyAgentAdjustment.AmountObj.Count > i; i++)
                    {
                        decimal amount = updatemodifyAgentAdjustment.AmountObj[i].adjustmentAmount;
                        int result = SqlHelper.ExecuteNonQuery(conn, CommandType.StoredProcedure, "usp_SaveModifyAgentAdjustments",
                                    new SqlParameter("@userId", updatemodifyAgentAdjustment.UserId),
                                    new SqlParameter("@AGENT_TRANS_ADJUST_ID", updatemodifyAgentAdjustment.AmountObj[i].adjustmentId),
                                    new SqlParameter("@NewAmt", amount),
                                    new SqlParameter("@VendorCode", updatemodifyAgentAdjustment.AmountObj[i].adjustmentVendorCode),
                                    new SqlParameter("@Action", updatemodifyAgentAdjustment.AmountObj[i].actionType)
                                    );
                        if (result != 0)
                        {
                            responseModel.Status = true;
                            responseModel.Message = "Data insert successfully.";
                            responseModel.Data = true;
                            return responseModel;
                        }
                        else
                        {
                            responseModel.Status = false;
                            responseModel.Message = "No record insert";
                            responseModel.Data = false;
                        }
                    }
                }
            }
            catch (Exception ex)
                {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "AddAgentSettling", updatemodifyAgentAdjustment.UserId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }

        /// <summary>
        /// Used for Get Pay code Description
        /// </summary>
        public Response GetPayCodeDesc(string userId, string payCode)
        {
            Response responseModel = new Response();
            try
            {
                using (SqlConnection conn = _dbContext.GetConnection())
                {
                    DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetPayCodeDescription",
                                    new SqlParameter("@userId", userId),
                                    new SqlParameter("@PayCode", payCode)
                                   );
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        responseModel.Status = true;
                        responseModel.Message = "Data get successfully.";
                        responseModel.Data = new DataSet[] { ds };
                        return responseModel;
                    }
                    else
                    {
                        responseModel.Status = false;
                        responseModel.Message = "No record found";
                        responseModel.Data = "";
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.WriteErrorLogInDB(LogTypes.Exception, ex, (int)Application.WebAPI, 0, 0, ex.Message, "GetModifyAgentAdjustmentsData", userId, _dbContext.GetLoggerConnection().ConnectionString);
            }
            return responseModel;
        }
        #endregion
    }
}
