﻿using EBHAPI.BusinessLayer.Interfaces;
using EBHAPI.Common;
using EBHAPI.Model;
using System.Data;
using System.Data.SqlClient;

namespace EBHAPI.BusinessLayer.EngineService
{
    public class CommonEngineService : ICommonEngineService
    {
        private BaseDataAccess _dbContext;

        public CommonEngineService(BaseDataAccess dbContext)
        {
            this._dbContext = dbContext;
        }

        public Response GetCountry(string userId, string countryCode)
        {
            Response responseModel = new Response();

            using (SqlConnection conn = _dbContext.GetConnection())
            {
                DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.StoredProcedure, "usp_GetCountry",
                                new SqlParameter("@userId", userId), 
                                new SqlParameter("@countryCode", countryCode)
                                );
                if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                {
                    responseModel.Status = true;
                    responseModel.Message = "Data get successfully.";
                    responseModel.Data = new DataSet[] { ds };
                    return responseModel;
                }
                else
                {
                    responseModel.Status = false;
                    responseModel.Message = "No record found";
                    responseModel.Data = "";
                    return responseModel;
                }
            }
        }
    }
}
