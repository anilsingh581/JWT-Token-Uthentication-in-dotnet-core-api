﻿using EBHAPI.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.BusinessLayer.Interfaces
{
    public interface IAgentSetllingEngineService
    {
        #region AgentSetlling
        /// <summary>
        /// THIS METHOD IS USED FOR GET AGENT SETLLING SUMMARY DETAILS
        /// </summary>
        Response GetAgentSetllingSummary(string userId);


        /// <summary>
        /// THIS METHOD IS USED FOR GET AGENT SETLLING GRID DETAILS
        /// </summary>
        Response GetAgentSetllingGrid(string userId);

        /// <summary>
        /// THIS METHOD IS USED FOR INSERT AGENT SETLLING GRID
        /// </summary>
        Response AddAgentSettling(string userId, string vendorCode, string agentCode, string AccountDate);

        /// <summary>
        /// THIS METHOD IS USED TO CHECK INSERTAGENTYOUARESETTLING FOR INSERT AGENT SETLLING GRID
        /// </summary>
        /// 
        Response CheckInsertAgentYouareSettling(string userId);

        /// <summary>
        /// THIS METHOD IS USED TO CHECK AAR_AGENTYOUARESETTLING FOR INSERT AGENT SETLLING GRID
        /// </summary>
        /// 
        Response CheckAgentStlVendorCodeForStl_AAR(string userId);


        /// <summary>
        /// THIS METHOD IS USED TO delete Agent SETLLING 
        /// </summary>
        /// 
        Response DeleteSettlingAgents(string userId, string vendorCode);


        /// <summary>
        /// THIS METHOD IS USED TO Get Summary ORDERDETAILS SETLLING GRID
        /// </summary>
        /// 
        Response GetSummaryOrderDetails(string userId, string vendorCode);


        /// <summary>
        /// THIS METHOD IS USED TO Get Adjustment Grid Detail SETLLING 
        /// </summary>
        /// 
        Response GetAdjustmentGridDetail(string userId, string vendorCode);

        /// <summary>
        /// THIS METHOD IS USED TO Get Summary ORDERDETAILS SETLLING Show Only Orders with Flags
        /// </summary>
        Response GetSummaryOrdersWithFlag(string userId, string vendorCode);

        /// <summary>
        /// THIS METHOD IS USED TO Get Summary ORDERDETAILS SETLLING Show Only Orders Next Week
        /// </summary>
        Response GetSummaryOrdersNextWeek(string userId, string vendorCode, string accountingWeek);


        /// <summary>
        /// THIS METHOD IS USED TO UPDATE Orders  SUMMARY DETAILS ACCOUNTING  Week
        /// </summary>
        Response UpdateMoveWeekData(MoveWeekObject moveWeekObjects);


        /// <summary>
        /// THIS METHOD IS USED FOR GET AGENT SETLLING SUMMARY DETAILS THOSE DATA HAVE NEGATIVE SETTLEMENT
        /// </summary>
        Response GetAgentSetllingSummaryNegativeSettlement(string userId);


        #endregion

        #region SettleOrderReviewDetail
        /// <summary>
        /// THIS METHOD IS USED FOR GET LIST OF SETTLE ORDER REVIEW DETAILS
        /// </summary>
        Response GetSettleOrderReviewDetail(string userId, string orderId);

        /// <summary>
        /// THIS METHOD IS USED FOR OverrideSettlementOrderReview
        /// </summary>
        Response OverrideSettlementOrderReview(string userId, int agentTransFlagId);

        #endregion

        #region ModifyAgentAdjustments
        /// <summary>
        /// THIS METHOD IS USED FOR GET MODIFY AGENT ADJUSTMENTS DATA
        /// </summary>
        Response GetModifyAgentAdjustmentsData(string userId, string vendorCode, int curAcctingWeek, string curAcctingDate, string agentCode);

        /// <summary>
        /// Save Modify Agent Adjustments 
        /// </summary>
        Response AddNewModifyAgentAdjustments(ModifyAgentAdjustment modifyAgentAdjustment);
        Response SaveModifyAgentAdjustments(UpdateModifyAgentAdjustment updatemodifyAgentAdjustment);
        Response GetPayCodeDesc(string userId, string payCode);

        #endregion
    }
}
