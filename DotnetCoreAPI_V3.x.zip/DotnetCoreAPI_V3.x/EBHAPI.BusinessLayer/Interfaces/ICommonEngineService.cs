﻿using EBHAPI.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.BusinessLayer.Interfaces
{
    public interface ICommonEngineService
    {
        Response GetCountry(string userId, string countryCode);
    }
}