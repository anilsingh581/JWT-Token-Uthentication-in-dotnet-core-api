﻿using EBHAPI.Model;

namespace EBHAPI.BusinessLayer.Interfaces
{
    public interface IAuthEngineService
    {
        User Authenticate(string username, string password);
    }
}
