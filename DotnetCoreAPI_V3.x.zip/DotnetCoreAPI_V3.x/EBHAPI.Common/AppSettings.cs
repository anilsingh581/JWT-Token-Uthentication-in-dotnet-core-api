﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Common
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
