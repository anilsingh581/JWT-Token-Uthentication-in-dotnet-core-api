﻿using System;

namespace EBHAPI.Common
{
    public class Constants
    {
        public const string app= "API";
    }
}
