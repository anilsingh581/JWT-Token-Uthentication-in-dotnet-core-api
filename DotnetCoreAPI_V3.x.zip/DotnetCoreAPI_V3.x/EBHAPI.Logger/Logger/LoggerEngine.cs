﻿using EBHAPI.Common;
using EBHAPI.Logger.Interface;
using EBHAPI.Logger.LogEntity;
using EBHAPI.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace EBHAPI.Logger.LogEngine
{
    public class LoggerEngine : ILogger
    {
        private BaseDataAccess _dbContext;

        public LoggerEngine()
        {
        }

        public LoggerEngine(BaseDataAccess dbContext)
        {
            this._dbContext = dbContext;
        }

        public void WriteErrorLogInDB(LogTypes logType, Exception exception, int applicationId, int componentId, int logLevel, string message, string context, string createdBy, string connectionString)
        {
            WriteLogIntoTable(applicationId, componentId, logLevel, exception.ToString(), context, createdBy, connectionString);
        }

        public void WriteLogIntoTable(int applicationId, int componentId, int logLevel, string message, string context, string createdBy, string connectionString)
        {
            Response responseModel = new Response();
            try
            {
                int result = SqlHelper.ExecuteNonQuery(connectionString, CommandType.StoredProcedure, "usp_InsertLogInfo",
                                   new SqlParameter("@applicationId", applicationId),
                                   new SqlParameter("@componentId", componentId),
                                   new SqlParameter("@logLevel", logLevel),
                                   new SqlParameter("@message", message),
                                   new SqlParameter("@context", context),
                                   new SqlParameter("@createdBy", createdBy));
                if (result > 0)
                {
                    responseModel.Status = true;
                    responseModel.Message = "Data insert successfully.";
                    responseModel.Data = true;
                }
                else
                {
                    responseModel.Status = false;
                    responseModel.Message = "No record insert";
                    responseModel.Data = false;
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}
