﻿using EBHAPI.Logger.LogEntity;
using System;

namespace EBHAPI.Logger.Interface
{
    public interface ILogger
    {
        void WriteErrorLogInDB(LogTypes logType, Exception exception, int applicationId, int componentId, int logLevel, string message, string context, string createdBy, string connectionString);
        void WriteLogIntoTable(int applicationId, int componentId, int logLevel, string message, string context, string createdBy, string connectionString);
    }
}
