﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBHAPI.Logger.LogEntity
{
    public enum LogTypes
    {
        Debug,
        Info,
        Warning,
        Exception
    }

    public enum Application
    {
        WebAPI=2
    }
}
